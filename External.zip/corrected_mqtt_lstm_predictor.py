
import paho.mqtt.client as mqtt
import json
import numpy as np
import pickle
import random
from tensorflow.keras.models import load_model
import threading
import pandas as pd

# --- Configurations ---
broker = "localhost"
port = 1883
topic = "home/power"

model_path = 'my_lstm_model.keras'
scaler_path = 'scaler.pkl'
output_file = 'appliance_data.txt'

appliance_names = [
    'WashingMachine_Power',
    'Heater_Power',
    'AC_Power',
    'VehicleCharger_Power',
    'VacuumCleaner_Power'
]
seq_length = 24
initial_fill_samples = 1440
max_buffer_size = 1440

# --- Load model and scaler ---
model = load_model(model_path)
with open(scaler_path, 'rb') as f:
    scaler = pickle.load(f)

# --- Buffers and Locks ---
data_buffer = []
daily_prediction_store = []
buffer_lock = threading.Lock()
buffer_pointer = 0

states = {}
averages = {}
binary_average_states = {}

def binarize_power_values(power_values, threshold_ratio=0.6):
    power_values = np.array(power_values)
    threshold = threshold_ratio * np.max(power_values)
    return (power_values >= threshold).astype(int)

def process_and_save_predictions(all_day_predictions, appliance_names, output_filename=output_file):
    window_size = 60
    num_windows = len(all_day_predictions) // window_size

    for idx, appliance_name in enumerate(appliance_names):
        power_series = all_day_predictions[:, idx]
        avg_list = []
        for i in range(num_windows):
            window = power_series[i * window_size : (i + 1) * window_size]
            avg = round(np.mean(window))
            avg_list.append(avg)

        threshold_ratio = 0.6 if appliance_name in ['AC_Power', 'Heater_Power', 'WashingMachine_Power'] else 0.8
        binary_states = binarize_power_values(avg_list, threshold_ratio=threshold_ratio)

        states[appliance_name] = np.array(binary_states)
        averages[appliance_name] = np.array(avg_list)
        binary_average_states[appliance_name] = binary_states

    for appliance_name, binary_states in binary_average_states.items():
        print(f"--- {appliance_name} Binary States ---")
        print(binary_states[:24])

    with open(output_filename, 'w') as f:
        for appliance_name in appliance_names:
            f.write(f"--- {appliance_name} ---\n")
            f.write("Average Power:\n")
            np.savetxt(f, averages[appliance_name].reshape(1, -1), fmt='%d', delimiter=', ')
            f.write("States:\n")
            np.savetxt(f, binary_average_states[appliance_name].reshape(1, -1), fmt='%d', delimiter=', ')
            f.write("\n")

    print("States and averages saved to appliance_data.txt")

def predict_on_buffer(buffer):
    global daily_prediction_store
    df = pd.DataFrame(buffer, columns=appliance_names)
    scaled_data = scaler.transform(df)
    x = [scaled_data[i:i + seq_length] for i in range(len(scaled_data) - seq_length)]
    x = np.array(x)
    preds_scaled = model.predict(x, verbose=0)
    preds = scaler.inverse_transform(preds_scaled)
    latest_pred = preds[-1]

    print("\n--- Appliance Averages and Binary States (Latest Prediction) ---")
    with open(output_file, 'w') as f:
        f.write("--- Appliance Averages and Binary States (Latest Prediction) ---\n")
        for idx, appliance in enumerate(appliance_names):
            avg = round(latest_pred[idx])
            threshold_ratio = 0.6 if appliance in ['AC_Power', 'Heater_Power', 'WashingMachine_Power'] else 0.8
            threshold = threshold_ratio * np.max(latest_pred)
            binary_state = int(avg >= threshold)
            print(f"{appliance}: Average={avg}, Binary State={binary_state}")
            f.write(f"{appliance}: Average={avg}, Binary State={binary_state}\n")

    daily_prediction_store.extend(preds.tolist())
    if len(daily_prediction_store) > 1440:
        daily_prediction_store = daily_prediction_store[-1440:]
    process_and_save_predictions(np.array(daily_prediction_store), appliance_names)

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("✅ Connected to MQTT Broker!")
        client.subscribe(topic)
    else:
        print(f"❌ Failed to connect, return code {rc}")

def on_message(client, userdata, msg):
    global data_buffer, buffer_pointer
    try:
        payload = json.loads(msg.payload.decode())
        values = [float(payload[appliance]) for appliance in appliance_names]

        with buffer_lock:
            if len(data_buffer) < max_buffer_size:
                data_buffer.append(values)
            else:
                data_buffer[buffer_pointer] = values
            print(f"Added/replaced sensor sample at index {buffer_pointer}: {values}")
            buffer_pointer = (buffer_pointer + 1) % max_buffer_size

            if len(data_buffer) >= seq_length + 30 and len(data_buffer) % 30 == 0:
                ordered_buffer = data_buffer[buffer_pointer:] + data_buffer[:buffer_pointer] if len(data_buffer) == max_buffer_size else data_buffer
                print("\nRunning prediction on buffered data (last 30 samples)...")
                recent_buffer = ordered_buffer[-(seq_length + 30):]
                predict_on_buffer(recent_buffer)
    except Exception as e:
        print("❌ Error processing MQTT message:", e)

def mqtt_loop():
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    print(f"Connecting to MQTT broker at {broker}:{port}...")
    client.connect(broker, port, 60)
    client.loop_forever()

# --- Main Execution ---
if __name__ == "__main__":
    print("🔄 Initial dummy prediction skipped. Starting MQTT loop only.")
    mqtt_loop()
